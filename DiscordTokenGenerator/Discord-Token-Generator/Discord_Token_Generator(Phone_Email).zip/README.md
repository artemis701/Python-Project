# Discord-Token-Generator
A program for mass create discord tokens

------------------------

# 🌟 Features 🌟
- Very fast multithreads
- Not detected by discord
- Custom password
- Support proxy
- Join server

------------------------

# ⚙️ Instructions ⚙️
1) [Download](https://github.com/odyzz/Discord-Token-Generator/archive/refs/heads/main.zip)
2) Configure it as you see fit in ``config.json``
3) Paste your proxies in ``proxies.txt``
4) Run `start.bat`
5) See results in `tokens.txt`

------------------------

# ⚠️ Disclaimer ⚠️
I am not responsible for what you do. The program is for educational purposes only!

------------------------

# 🖼️ Preview 🖼️

![Preview](https://i.imgur.com/qbM49sI.png)
