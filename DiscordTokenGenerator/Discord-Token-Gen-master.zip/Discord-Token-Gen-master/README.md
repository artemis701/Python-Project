<h1 align="center">
    <b>JOIN DISCORD SERVER https://discord.gg/boost69 PREVIOUS got termed</b>
</h1>

<p align="center">
- 220 stars release paid private premium unlocked token gen<br>
- 225 release the only working undetected ai hcaptcha solver
</p>

# Discord-Token-Gen
An auto discord token generator. Auto verifies phone number but not email. Still working on it.

<img src="https://github.com/LanLan69/Discord-Token-Gen/blob/master/%E6%88%AA%E5%B1%8F2022-03-17%2016.28.47.png"/>

# How to use

**WILL NOT WORK WITHOUT API KEY**

put your [capmonster](https://www.capmonster.com) key in main.py
and your [onlinesim.ru](https://onlinesim.io?ref=3203672) key in main.py.

capmonster is for hcaptcha solve and onlinesim.ru is for phone verfication.

```python
class Settings:
    capmonster = "YOUR-CAPMONSTER-KEY"
    onlinesimru = "YOUR-ONLINESIMRU-KEY"
```

```bash
python3 main.py
```

__**EZ PROFIT 2k$ / day**__

# CONTACT / Help 
Discord : LanLan#0001

# DISCLAIMER
This github repo is for **EDUCATIONAL PURPOSES ONLY. I AM NOT RESPONSIBLE FOR WHAT YOU DO WITH THIS REPO.**
